window.mermaid = { startOnLoad: true };
